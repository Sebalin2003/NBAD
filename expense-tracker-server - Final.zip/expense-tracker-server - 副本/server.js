const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Serve the static files for the web interface
app.use(express.static(path.join(__dirname, 'public')));

// In-memory storage for expenses (for demonstration purposes)
let expenses = [];
let nextId = 1;

// API endpoints
app.get('/expenses', (req, res) => {
  res.json(expenses);
});

app.post('/expenses', (req, res) => {
  const { name, amount, category } = req.body;
  if (!name || !amount || !category) {
    return res.status(400).json({ message: 'All fields are required' });
  }
  const expense = { id: nextId++, name, amount: parseFloat(amount), category };
  expenses.push(expense);
  res.status(201).json(expense);
});

app.put('/expenses/:id', (req, res) => {
  const { id } = req.params;
  const { name, amount, category } = req.body;
  const expenseIndex = expenses.findIndex(exp => exp.id === parseInt(id));
  if (expenseIndex === -1) {
    return res.status(404).json({ message: 'Expense not found' });
  }
  expenses[expenseIndex] = { ...expenses[expenseIndex], name, amount: parseFloat(amount), category };
  res.json(expenses[expenseIndex]);
});

app.delete('/expenses/:id', (req, res) => {
  const { id } = req.params;
  const expenseIndex = expenses.findIndex(exp => exp.id === parseInt(id));
  if (expenseIndex === -1) {
    return res.status(404).json({ message: 'Expense not found' });
  }
  expenses.splice(expenseIndex, 1);
  res.status(204).send();
});

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`Server is running on http://< 192.168.240.96>:${port}`);
});

